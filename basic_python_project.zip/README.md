# Basic Python Project

This is a simple Python project demonstrating a basic CLI calculator.

## Features
- Add, subtract, multiply, divide
- Clean and simple structure

## How to run
```
python main.py
```
